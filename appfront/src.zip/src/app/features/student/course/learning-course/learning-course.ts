import { ChangeDetectorRef, Component, inject, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Api } from '../../../../api/api';
import { CourseContentResponse, LessonContentResponse } from '../../../../models/learning.model';
import { apiCourseContent } from '../../../../api/functions';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-learning-course',
  imports: [CommonModule],
  templateUrl: './learning-course.html',
  styleUrl: './learning-course.css',
})
export class LearningCourse implements OnInit {
  private cdr = inject(ChangeDetectorRef);

  constructor(
    private route: ActivatedRoute,
    private api: Api
  ) { }

  loading = true;
  course?: CourseContentResponse;
  selectedLesson?: LessonContentResponse;

  ngOnInit(): void {
    const idCourse = this.route.snapshot.paramMap.get('idCourse');
    if (idCourse) {
      this.loadCourse(idCourse);
    }
  }

  loadCourse(idCourse: string) {
    this.loading = true;
    this.api.invoke(apiCourseContent, { idCourse })
      .then((response: any) => {

        const data =
          typeof response === "string" ? JSON.parse(response) : response;
        this.course = data.data ?? data;
        if (this.course?.lessons.length) {
          this.selectedLesson =
            this.course.lessons[0];
        }
      })
      .finally(() => {
        this.loading = false;
        this.cdr.detectChanges();
      });
  }

  selectLesson(lesson: LessonContentResponse) {
    this.selectedLesson = lesson;
  }
}

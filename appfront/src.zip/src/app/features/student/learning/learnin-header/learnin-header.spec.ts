import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LearninHeader } from './learnin-header';

describe('LearninHeader', () => {
  let component: LearninHeader;
  let fixture: ComponentFixture<LearninHeader>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LearninHeader]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LearninHeader);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

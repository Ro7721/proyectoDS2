import { Component } from '@angular/core';

@Component({
  selector: 'app-learnin-header',
  imports: [],
  templateUrl: './learnin-header.html',
  styleUrl: './learnin-header.css',
})
export class LearninHeader {

}

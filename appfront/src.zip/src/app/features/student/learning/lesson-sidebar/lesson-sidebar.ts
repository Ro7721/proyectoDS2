import { Component } from '@angular/core';

@Component({
  selector: 'app-lesson-sidebar',
  imports: [],
  templateUrl: './lesson-sidebar.html',
  styleUrl: './lesson-sidebar.css',
})
export class LessonSidebar {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-lesson-resource',
  imports: [],
  templateUrl: './lesson-resource.html',
  styleUrl: './lesson-resource.css',
})
export class LessonResource {

}

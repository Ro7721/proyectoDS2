import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Api } from '../../../../api/api';
import { Apicoursesbyteacher$Params, apicoursesbyteacher, apigetallCategory } from '../../../../api/functions';
import { CourseResponse } from '../../../../models/course.model';
import { ButtonModule } from 'primeng/button';
import { SkeletonModule } from 'primeng/skeleton';
import { TagModule } from 'primeng/tag';
import { Toast } from 'primeng/toast';
import { CourseDetails } from '../course-details/course-details';
import { AuthService } from '../../../../core/auth/auth.service';
import { MessageToast } from '../../../../message/message-toast';
import { CategoryResponse } from '../../../../models/category.model';
import { SelectModule } from 'primeng/select';

@Component({
  selector: 'app-course-getall',
  imports: [CommonModule, RouterLink, ButtonModule, TagModule, SkeletonModule, Toast, CourseDetails, SelectModule],
  templateUrl: './course-getall.html',
  styleUrl: './course-getall.css',
})
export class CourseGetall implements OnInit {
  private api = inject(Api);
  private cdr = inject(ChangeDetectorRef);
  private authService = inject(AuthService);

  listCourses: CourseResponse[] = [];
  selectedCourseId: string | null = null;
  loading = true;
  showDetails = false;
  notFound = false;
  teacherId = this.authService.user?.idUser || '';
  categories: CategoryResponse[] = [];

  constructor(private toastMessage: MessageToast) { }

  ngOnInit(): void {
    this.loadCourses();
    this.loadCategories();
  }

  loadCourses(): void {
    this.loading = true;
    this.notFound = false;

    this.api
      .invoke<Apicoursesbyteacher$Params, any>(apicoursesbyteacher, {
        teacherId: this.teacherId,
      })
      .then((response) => {
        this.listCourses = response?.data ?? [];
        this.notFound = this.listCourses.length === 0;
        this.loading = false;
        this.cdr.detectChanges();
      })
      .catch((error) => {
        this.toastMessage.toastError('Error al cargar cursos', error?.message || 'Ocurrio un error');
        this.listCourses = [];
        this.loading = false;
        this.notFound = true;
        this.cdr.detectChanges();
      });
  }

  openCourseDetail(course: CourseResponse): void {
    this.selectedCourseId = course.idCourse;
    this.showDetails = true;
  }

  onDetailsVisibilityChange(visible: boolean): void {
    this.showDetails = visible;
    if (!visible) {
      this.selectedCourseId = null;
    }
  }

  getLevelSeverity(level: string): 'success' | 'info' | 'warn' | 'danger' | 'secondary' | 'contrast' {
    const map: Record<string, 'success' | 'info' | 'warn'> = {
      BASICO: 'success',
      INTERMEDIO: 'info',
      AVANZADO: 'warn',
    };
    return map[level?.toUpperCase()] ?? 'info';
  }

  getStatusSeverity(status: string): 'success' | 'warn' | 'secondary' {
    const map: Record<string, 'success' | 'warn' | 'secondary'> = {
      PUBLICADO: 'success',
      BORRADOR: 'secondary',
      PAUSADO: 'warn',
    };
    return map[status?.toUpperCase()] ?? 'secondary';
  }

  formatPrice(price: number): string {
    if (!price) return 'Gratis';
    return new Intl.NumberFormat('es-PE', { style: 'currency', currency: 'PEN' }).format(price);
  }

  loadCategories() {
    this.api.invoke(apigetallCategory).then((response: any) => {
      const apiResponse = typeof response == 'string' ? JSON.parse(response) : response;
      if (Array.isArray(apiResponse)) {
        this.categories = apiResponse;
      } else if (apiResponse && Array.isArray(apiResponse.data)) {
        this.categories = apiResponse.data;
      }
      this.cdr.detectChanges();
    }).catch((error) => {
      this.toastMessage.toastError('Error al cargar categorias', error?.message || 'Ocurrio un error');
      this.categories = [];
      this.cdr.detectChanges();
    });
  }
  courseFilterByCategory(category: CategoryResponse) {
    this.loading = true;
    this.notFound = false;

    this.api
      .invoke<Apicoursesbyteacher$Params, any>(apicoursesbyteacher, {
        teacherId: this.teacherId,
      })
      .then((response) => {
        this.listCourses = response?.data ?? [];
        this.notFound = this.listCourses.length === 0;
        this.loading = false;
        this.cdr.detectChanges();
      })
      .catch((error) => {
        this.toastMessage.toastError('Error al cargar cursos', error?.message || 'Ocurrio un error');
        this.listCourses = [];
        this.loading = false;
        this.notFound = true;
        this.cdr.detectChanges();
      });
  }
}

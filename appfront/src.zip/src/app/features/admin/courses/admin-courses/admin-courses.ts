import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Api } from '../../../../api/api';
import { getAllCourses } from '../../../../api/functions';
import { CourseResponse } from '../../../../api/models/course-response';

@Component({
  selector: 'app-admin-courses',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-courses.html',
  styleUrl: './admin-courses.css'
})
export class AdminCoursesComponent implements OnInit {
  courses: CourseResponse[] = [];
  filteredCourses: CourseResponse[] = [];
  loading = true;
  error = '';
  searchQuery = '';

  constructor(private api: Api) { }

  ngOnInit(): void {
    this.loadCourses();
  }

  loadCourses() {
    this.loading = true;
    this.api.invoke(getAllCourses).then((response: any) => {
      const parsed = typeof response === 'string' ? JSON.parse(response) : response;
      if (Array.isArray(parsed)) {
        this.courses = parsed;
        this.filteredCourses = this.courses;
      } else if (parsed.data) {
        this.courses = parsed.data;
        this.filteredCourses = this.courses;
      }
    }).catch(err => {
      this.error = 'Error cargando los cursos';
      console.error(err);
    }).finally(() => {
      this.loading = false;
    });
  }

  onSearch(event: Event) {
    const value = (event.target as HTMLInputElement).value.toLowerCase();
    this.searchQuery = value;
    this.filteredCourses = this.courses.filter(course =>
      (course.title?.toLowerCase() || '').includes(value) ||
      (course.teacherFullName?.toLowerCase() || '').includes(value) ||
      (course.categoryName?.toLowerCase() || '').includes(value)
    );
  }
}

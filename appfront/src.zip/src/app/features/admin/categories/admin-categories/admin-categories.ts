import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Api } from '../../../../api/api';
import { getAll1 as getAllCategories } from '../../../../api/functions';
import { CategoryResponse } from '../../../../api/models/category-response';

@Component({
  selector: 'app-admin-categories',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-categories.html',
  styleUrl: './admin-categories.css'
})
export class AdminCategoriesComponent implements OnInit {
  categories: CategoryResponse[] = [];
  filteredCategories: CategoryResponse[] = [];
  loading = true;
  error = '';
  searchQuery = '';

  constructor(readonly api: Api) { }

  ngOnInit(): void {
    this.loadCategories();
  }

  loadCategories() {
    this.loading = true;
    this.api.invoke(getAllCategories).then((response: any) => {
      const parsed = typeof response === 'string' ? JSON.parse(response) : response;
      if (Array.isArray(parsed)) {
        this.categories = parsed;
        this.filteredCategories = this.categories;
      } else if (parsed.data) {
        this.categories = parsed.data;
        this.filteredCategories = this.categories;
      }
    }).catch(err => {
      this.error = 'Error cargando las categorías';
      console.error(err);
    }).finally(() => {
      this.loading = false;
    });
  }

  onSearch(event: Event) {
    const value = (event.target as HTMLInputElement).value.toLowerCase();
    this.searchQuery = value;
    this.filteredCategories = this.categories.filter(category =>
      (category.name?.toLowerCase() || '').includes(value) ||
      (category.description?.toLowerCase() || '').includes(value)
    );
  }
}

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Api } from '../../../../api/api';
import { getAll } from '../../../../api/functions';
import { EnrollmentResponse } from '../../../../api/models/enrollment-response';

@Component({
  selector: 'app-admin-enrollments',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-enrollments.html',
  styleUrl: './admin-enrollments.css'
})
export class AdminEnrollmentsComponent implements OnInit {
  enrollments: EnrollmentResponse[] = [];
  filteredEnrollments: EnrollmentResponse[] = [];
  loading = true;
  error = '';
  searchQuery = '';

  constructor(private api: Api) {}

  ngOnInit(): void {
    this.loadEnrollments();
  }

  loadEnrollments() {
    this.loading = true;
    this.api.invoke(getAll).then((response: any) => {
      const parsed = typeof response === 'string' ? JSON.parse(response) : response;
      if (Array.isArray(parsed)) {
        this.enrollments = parsed;
        this.filteredEnrollments = this.enrollments;
      } else if (parsed.data) {
        this.enrollments = parsed.data;
        this.filteredEnrollments = this.enrollments;
      }
    }).catch(err => {
      this.error = 'Error cargando las inscripciones';
      console.error(err);
    }).finally(() => {
      this.loading = false;
    });
  }

  onSearch(event: Event) {
    const value = (event.target as HTMLInputElement).value.toLowerCase();
    this.searchQuery = value;
    this.filteredEnrollments = this.enrollments.filter(enr => 
      (enr.courseTitle?.toLowerCase() || '').includes(value) ||
      (enr.studentName?.toLowerCase() || '').includes(value)
    );
  }
}

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Api } from '../../../../api/api';
import { getAllUsers } from '../../../../api/functions';
import { UserResponse } from '../../../../api/models/user-response';

@Component({
  selector: 'app-admin-users',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-users.html',
  styleUrl: './admin-users.css'
})
export class AdminUsersComponent implements OnInit {
  users: UserResponse[] = [];
  filteredUsers: UserResponse[] = [];
  loading = true;
  error = '';
  searchQuery = '';

  constructor(private api: Api) { }

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers() {
    this.loading = true;
    this.api.invoke(getAllUsers).then((response: any) => {
      const parsed = typeof response === 'string' ? JSON.parse(response) : response;
      if (Array.isArray(parsed)) {
        this.users = parsed;
        this.filteredUsers = this.users;
      } else if (parsed.data) {
        this.users = parsed.data;
        this.filteredUsers = this.users;
      }
    }).catch(err => {
      this.error = 'Error cargando los usuarios';
      console.error(err);
    }).finally(() => {
      this.loading = false;
    });
  }

  onSearch(event: Event) {
    const value = (event.target as HTMLInputElement).value.toLowerCase();
    this.searchQuery = value;
    this.filteredUsers = this.users.filter(user =>
      (user.firstName?.toLowerCase() || '').includes(value) ||
      (user.surName?.toLowerCase() || '').includes(value) ||
      (user.email?.toLowerCase() || '').includes(value) ||
      (user.role?.toLowerCase() || '').includes(value)
    );
  }
}

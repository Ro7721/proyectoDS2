import { inject, Injectable, PLATFORM_ID } from '@angular/core';
import { Router } from '@angular/router';
import { Api } from '../../api/api';
import { isPlatformBrowser } from '@angular/common';
import { CurrentUser, LoginResponse, RefreshTokenResponse } from '../../models/auth.model';
import { login, getCurrentUser1, refreshToken } from '../../api/functions';

export type AppRole = 'ROLE_ADMIN' | 'ROLE_TEACHER' | 'ROLE_STUDENT';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private router = inject(Router);
  private plataformId = inject(PLATFORM_ID);
  private isBrowser = () => isPlatformBrowser(this.plataformId);
  constructor(private api: Api) { }

  async login(email: string, password: string): Promise<LoginResponse> {
    const rawResponse: any = await this.api.invoke(login, {
      body: {
        email,
        password
      }
    });
    const response: LoginResponse = rawResponse.data ?? rawResponse;
    this.saveSession(response);
    return response;
  }

  // Traer el usuario actual para mostrar información en el header
  async getCurrentUser(): Promise<CurrentUser> {
    const rawResponse: any = await this.api.invoke(getCurrentUser1, {});
    const response: CurrentUser = rawResponse.data ?? rawResponse;
    return response;
  }
  //Verifica si el usuario esta autenticado
  async ensureAuthenticated(): Promise<boolean> {
    if (this.isAuthenticated()) return true;
    if (!this.refreshToken) return false;

    try {
      const response = await this.refreshAccessToken();
      return Boolean(response?.accessToken);
    } catch {
      this.clearSession();
      return false;
    }
  }
  //Refresh token 
  async refreshAccessToken(): Promise<RefreshTokenResponse | null> {
    const storedRefreshToken = this.refreshToken;
    if (!storedRefreshToken) return null;

    const rawResponse: any = await this.api.invoke(refreshToken, {
      body: { refreshToken: storedRefreshToken },
    });
    const response: RefreshTokenResponse = rawResponse.data ?? rawResponse;

    if (this.isBrowser()) {
      localStorage.setItem('accessToken', response.accessToken);
      localStorage.setItem('expiresIn', String(response.expiresIn));
      localStorage.setItem('tokenType', response.tokenType);
      this.saveTokenExpiration(response.accessToken);
    }

    return response;
  }

  logout(): void {
    this.clearSession();
    this.router.navigate(['']);
  }
  // Verifica si el usuario esta autenticado
  isAuthenticated(): boolean {
    const token = this.accessToken;
    return Boolean(token && !this.isTokenExpired(token));
  }
  // Verifica si el usuario tiene alguno de los roles permitidos
  hasAnyRole(allowedRoles: string[]): boolean {
    if (allowedRoles.length === 0) return true;

    const currentRole = this.currentRole;
    if (!currentRole) return false;

    return allowedRoles
      .map((role) => this.normalizeRole(role))
      .includes(currentRole);
  }

  get accessToken(): string | null {
    return this.isBrowser() ? localStorage.getItem('accessToken') : null;
  }

  get refreshToken(): string | null {
    return this.isBrowser() ? localStorage.getItem('refreshToken') : null;
  }

  get user(): LoginResponse['user'] | null {
    if (!this.isBrowser()) return null;

    const storedUser = localStorage.getItem('user');
    return storedUser ? JSON.parse(storedUser) : null;
  }

  get currentRole(): AppRole | null {
    if (!this.isBrowser()) return null;

    const storedRole = localStorage.getItem('role');
    if (storedRole) return this.normalizeRole(storedRole);

    const userRole = this.user?.role;
    return userRole ? this.normalizeRole(userRole) : null;
  }
  get isLoggedIn(): boolean {
    return this.isAuthenticated();
  }
  isStudent(): boolean {
    return this.currentRole === "ROLE_STUDENT";
  }
  isTeacher(): boolean {
    return this.currentRole === "ROLE_TEACHER";
  }

  getRoleHomeUrl(role: AppRole | null = this.currentRole): string[] {
    switch (role) {
      case 'ROLE_TEACHER':
        return ['/dashboard/overview-teacher'];
      case 'ROLE_ADMIN':
        return ['/dashboard/admin'];
      case 'ROLE_STUDENT':
        return ['/dashboard/my-courses'];
      default:
        return ['/auth/login'];
    }
  }

  getTokenType(): string {
    return this.isBrowser() ? (localStorage.getItem('tokenType') ?? 'Bearer') : 'Bearer';
  }
  // Guarda la sesión del usuario en el localStorage
  private saveSession(response: LoginResponse): void {
    if (!response?.accessToken) {
      throw new Error('Token inválido');
    }
    if (!this.isBrowser()) return;

    localStorage.setItem('accessToken', response.accessToken);
    localStorage.setItem('refreshToken', response.refreshToken);
    localStorage.setItem('expiresIn', String(response.expiresIn));
    localStorage.setItem('tokenType', response.tokenType);
    localStorage.setItem('user', JSON.stringify(response.user));
    localStorage.setItem('role', this.normalizeRole(response.user.role));
    this.saveTokenExpiration(response.accessToken);
  }
  // Limpia la sesión del usuario
  private clearSession(): void {
    if (!this.isBrowser()) return;

    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('expiresIn');
    localStorage.removeItem('tokenType');
    localStorage.removeItem('tokenExpiresAt');
    localStorage.removeItem('user');
    localStorage.removeItem('role');
  }

  private normalizeRole(role: string): AppRole {
    const normalized = role.trim().toUpperCase().replace(/^ROLE_/, '');
    const roleMap: Record<string, AppRole> = {
      ADMIN: 'ROLE_ADMIN',
      ADMINISTRADOR: 'ROLE_ADMIN',
      TEACHER: 'ROLE_TEACHER',
      PROFESOR: 'ROLE_TEACHER',
      DOCENTE: 'ROLE_TEACHER',
      STUDENT: 'ROLE_STUDENT',
      ALUMNO: 'ROLE_STUDENT',
      ESTUDIANTE: 'ROLE_STUDENT',
    };

    return roleMap[normalized] ?? 'ROLE_STUDENT';
  }

  private saveTokenExpiration(token: string): void {
    if (!this.isBrowser()) return;

    const exp = this.getTokenExpiration(token);
    if (exp) {
      localStorage.setItem('tokenExpiresAt', String(exp.getTime()));
    }
  }

  private isTokenExpired(token: string): boolean {
    const expiration = this.getTokenExpiration(token);
    if (!expiration) return true;

    return expiration.getTime() <= Date.now();
  }

  private getTokenExpiration(token: string): Date | null {
    const payload = this.decodeJwtPayload(token);
    if (!payload?.exp) return null;

    return new Date(payload.exp * 1000);
  }

  private decodeJwtPayload(token: string): { exp?: number } | null {
    if (!this.isBrowser()) return null;

    try {
      const payload = token.split('.')[1];
      const base64 = payload.replace(/-/g, '+').replace(/_/g, '/');
      const json = decodeURIComponent(
        atob(base64)
          .split('')
          .map((char) => `%${`00${char.charCodeAt(0).toString(16)}`.slice(-2)}`)
          .join(''),
      );

      return JSON.parse(json);
    } catch {
      return null;
    }
  }
}
